package com.example.ui.viewmodel

import android.app.Application
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

data class ChatUiState(
    val isLoggedIn: Boolean = false,
    val userEmail: String? = null,
    val userName: String? = null,
    val currentSessionId: String = "",
    val messages: List<ChatMessageEntity> = emptyList(),
    val sessions: List<ChatSessionEntity> = emptyList(),
    val starredMessages: List<ChatMessageEntity> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val selectedImageBase64: String? = null,
    val activeCategory: String = "All",
    val selectedModel: String = "gemini-3.5-flash",
    val isSpeaking: Boolean = false,
    val speakingMessageId: Long? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repository: ChatRepository
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    init {
        val database = AppDatabase.getInstance(application)
        repository = ChatRepository(database.chatDao())
        
        // Initialize TTS
        tts = TextToSpeech(application, this)

        // Observe Sessions
        viewModelScope.launch {
            repository.allSessions.collectLatest { sessionList ->
                _uiState.update { it.copy(sessions = sessionList) }
                
                // If no current session, pick first or create new
                if (_uiState.value.currentSessionId.isBlank()) {
                    if (sessionList.isNotEmpty()) {
                        loadSession(sessionList.first().sessionId)
                    } else {
                        createNewChat()
                    }
                }
            }
        }

        // Observe Starred Messages
        viewModelScope.launch {
            repository.starredMessages.collectLatest { starred ->
                _uiState.update { it.copy(starredMessages = starred) }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            ttsReady = true
        }
    }

    fun loadSession(sessionId: String) {
        _uiState.update { it.copy(currentSessionId = sessionId, errorMessage = null) }
        viewModelScope.launch {
            repository.getMessagesForSession(sessionId).collectLatest { msgs ->
                _uiState.update { it.copy(messages = msgs) }
            }
        }
    }

    fun createNewChat(title: String = "New Chat", category: String = "General") {
        viewModelScope.launch {
            val newId = repository.createNewSession(title, category)
            loadSession(newId)
        }
    }

    fun sendMessage(promptText: String) {
        val cleanPrompt = promptText.trim()
        if (cleanPrompt.isBlank() && _uiState.value.selectedImageBase64 == null) return

        val sessionId = _uiState.value.currentSessionId
        val imageBase64 = _uiState.value.selectedImageBase64
        val currentHistory = _uiState.value.messages
        val model = _uiState.value.selectedModel

        // Clear image attachment and set loading state
        _uiState.update { it.copy(selectedImageBase64 = null, isLoading = true, errorMessage = null) }

        viewModelScope.launch {
            // Save user message to DB
            repository.saveUserMessage(sessionId, cleanPrompt, imageBase64)

            // Query NEW GEN AI
            val result = repository.sendMessageToNewGenAi(
                sessionId = sessionId,
                promptText = cleanPrompt,
                imageBase64 = imageBase64,
                history = currentHistory,
                modelName = model
            )

            _uiState.update { state ->
                state.copy(
                    isLoading = false,
                    errorMessage = result.exceptionOrNull()?.message
                )
            }
        }
    }

    fun setSelectedImage(bytes: ByteArray?) {
        val base64 = if (bytes != null) {
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } else null
        _uiState.update { it.copy(selectedImageBase64 = base64) }
    }

    fun clearSelectedImage() {
        _uiState.update { it.copy(selectedImageBase64 = null) }
    }

    fun setCategory(category: String) {
        _uiState.update { it.copy(activeCategory = category) }
    }

    fun setModel(model: String) {
        _uiState.update { it.copy(selectedModel = model) }
    }

    fun toggleStar(messageId: Long, currentStarred: Boolean) {
        viewModelScope.launch {
            repository.toggleStarMessage(messageId, currentStarred)
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_uiState.value.currentSessionId == sessionId) {
                val remaining = _uiState.value.sessions.filter { it.sessionId != sessionId }
                if (remaining.isNotEmpty()) {
                    loadSession(remaining.first().sessionId)
                } else {
                    createNewChat()
                }
            }
        }
    }

    fun speakText(messageId: Long, text: String) {
        if (!ttsReady || tts == null) return
        if (_uiState.value.speakingMessageId == messageId && tts?.isSpeaking == true) {
            tts?.stop()
            _uiState.update { it.copy(isSpeaking = false, speakingMessageId = null) }
        } else {
            tts?.stop()
            _uiState.update { it.copy(isSpeaking = true, speakingMessageId = messageId) }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MSG_$messageId")
        }
    }

    fun login(email: String, name: String) {
        _uiState.update {
            it.copy(
                isLoggedIn = true,
                userEmail = email,
                userName = name
            )
        }
    }

    fun logout() {
        _uiState.update {
            it.copy(
                isLoggedIn = false,
                userEmail = null,
                userName = null
            )
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
