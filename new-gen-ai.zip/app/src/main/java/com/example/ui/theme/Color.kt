package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AiCyan80 = Color(0xFF80F1FF)
val AiPurple80 = Color(0xFFC4B5FD)
val AiPink80 = Color(0xFFFCA5A5)

val AiCyan40 = Color(0xFF0284C7)
val AiPurple40 = Color(0xFF7C3AED)
val AiPink40 = Color(0xFFE11D48)

val DarkBg = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF151D2A)
val DarkCard = Color(0xFF1E293B)
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF1F5F9)

val AiAccentCyan = Color(0xFF00E5FF)
val AiAccentPurple = Color(0xFFA855F7)
val AiAccentGreen = Color(0xFF10B981)
