package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.AboutCreatorDialog
import com.example.ui.components.ChatInputBar
import com.example.ui.components.ChatMessageItem
import com.example.ui.components.HeaderSection
import com.example.ui.components.HistoryDrawerSheet
import com.example.ui.components.PromptCategoryChips
import com.example.ui.theme.AiAccentCyan
import com.example.ui.theme.AiAccentPurple
import com.example.ui.viewmodel.ChatViewModel

@Composable
fun MainChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showAboutDialog by remember { mutableStateOf(false) }
    var showHistorySheet by remember { mutableStateOf(false) }
    var drawerInitialTab by remember { mutableStateOf(0) }

    // Auto-scroll to bottom on new message
    LaunchedEffect(uiState.messages.size, uiState.isLoading) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    // Show error message in snackbar if present
    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { err ->
            snackbarHostState.showSnackbar(err)
            viewModel.dismissError()
        }
    }

    Scaffold(
        topBar = {
            HeaderSection(
                selectedModel = uiState.selectedModel,
                onModelSelected = { viewModel.setModel(it) },
                onOpenHistory = {
                    drawerInitialTab = 0
                    showHistorySheet = true
                },
                onOpenInfo = { showAboutDialog = true },
                onNewChat = { viewModel.createNewChat() },
                onOpenStarred = {
                    drawerInitialTab = 1
                    showHistorySheet = true
                },
                starredCount = uiState.starredMessages.size,
                userName = uiState.userName,
                userEmail = uiState.userEmail,
                onSignOut = { viewModel.logout() }
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            ChatInputBar(
                selectedImageBase64 = uiState.selectedImageBase64,
                onImageSelected = { viewModel.setSelectedImage(it) },
                onClearImage = { viewModel.clearSelectedImage() },
                onSendMessage = { viewModel.sendMessage(it) },
                isLoading = uiState.isLoading
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Category Chips & Quick Prompts
            PromptCategoryChips(
                activeCategory = uiState.activeCategory,
                onCategorySelected = { viewModel.setCategory(it) },
                onPromptSelected = { promptText ->
                    viewModel.sendMessage(promptText)
                }
            )

            // Chat Messages / Welcome Hero
            if (uiState.messages.isEmpty()) {
                // Empty state: Hero Greeting
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(
                                width = 1.dp,
                                brush = Brush.linearGradient(listOf(AiAccentCyan, AiAccentPurple)),
                                shape = RoundedCornerShape(24.dp)
                            )
                            .padding(20.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(AiAccentCyan, AiAccentPurple))
                                )
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                                contentDescription = "NEW GEN AI Hero Logo",
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Welcome to NEW GEN AI",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "Created by Amit Dantani",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = AiAccentCyan
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "\"I was created by Amit Dantani. I am NEW GEN AI, built to help people with learning, creativity, and everyday tasks.\"",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Capability Quick Grid
                        Row(
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            HeroCapabilityChip("Homework & Math", Icons.Default.School) {
                                viewModel.sendMessage("Explain Pythagorean theorem with step-by-step example problem.")
                            }
                            HeroCapabilityChip("Code & Tech", Icons.Default.Code) {
                                viewModel.sendMessage("Write a clean Kotlin function to calculate Fibonacci sequence.")
                            }
                            HeroCapabilityChip("Creative Writing", Icons.Default.AutoAwesome) {
                                viewModel.sendMessage("Write a creative short story about a futuristic city.")
                            }
                        }
                    }
                }
            } else {
                // Messages List
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(uiState.messages, key = { it.messageId }) { msg ->
                        ChatMessageItem(
                            message = msg,
                            onToggleStar = { id, current -> viewModel.toggleStar(id, current) },
                            onSpeak = { id, text -> viewModel.speakText(id, text) },
                            isSpeakingThisMessage = uiState.speakingMessageId == msg.messageId
                        )
                    }

                    // Thinking Indicator
                    if (uiState.isLoading) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = AiAccentCyan,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "NEW GEN AI is thinking & crafting answer...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = AiAccentCyan
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modals
    if (showAboutDialog) {
        AboutCreatorDialog(onDismiss = { showAboutDialog = false })
    }

    if (showHistorySheet) {
        HistoryDrawerSheet(
            sessions = uiState.sessions,
            starredMessages = uiState.starredMessages,
            currentSessionId = uiState.currentSessionId,
            onSelectSession = { viewModel.loadSession(it) },
            onNewChat = { viewModel.createNewChat() },
            onDeleteSession = { viewModel.deleteSession(it) },
            onDismiss = { showHistorySheet = false },
            initialTab = drawerInitialTab
        )
    }
}

@Composable
private fun HeroCapabilityChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AiAccentCyan,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
