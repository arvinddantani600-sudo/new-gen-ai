package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AiAccentCyan
import com.example.ui.theme.AiAccentPurple

data class CategoryItem(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val samplePrompts: List<String>
)

val CATEGORIES = listOf(
    CategoryItem(
        id = "homework",
        label = "Homework & Edu",
        icon = Icons.Default.MenuBook,
        samplePrompts = listOf(
            "Explain Newton's Laws of Motion with real-life everyday examples.",
            "Summarize the main causes of World War II in 5 clear bullet points.",
            "Write a study notes guide for human cell structure and biology."
        )
    ),
    CategoryItem(
        id = "math",
        label = "Mathematics",
        icon = Icons.Default.Functions,
        samplePrompts = listOf(
            "Solve step-by-step: Find integral of x^2 * e^x dx",
            "Explain Pythagorean Theorem and how to calculate hypotenuse.",
            "What is the derivative of sin(x)*cos(x)? Show all steps."
        )
    ),
    CategoryItem(
        id = "science",
        label = "Science",
        icon = Icons.Default.Science,
        samplePrompts = listOf(
            "How does photosynthesis work in plants?",
            "Explain Einstein's Theory of General Relativity in simple terms.",
            "What is the periodic table trend for electronegativity?"
        )
    ),
    CategoryItem(
        id = "coding",
        label = "Coding & Dev",
        icon = Icons.Default.Code,
        samplePrompts = listOf(
            "Write a clean Kotlin Jetpack Compose LazyColumn with search filter.",
            "How do I parse JSON in Python using native json module?",
            "Explain binary search algorithm with time complexity analysis."
        )
    ),
    CategoryItem(
        id = "writing",
        label = "Creative Writing",
        icon = Icons.Default.Create,
        samplePrompts = listOf(
            "Write a poem about futuristic AI helping humanity explore space.",
            "Draft a professional polite leave request email to my manager.",
            "Write a short suspenseful opening story script set in a cyberpunk city."
        )
    ),
    CategoryItem(
        id = "translation",
        label = "Multi-Language",
        icon = Icons.Default.Language,
        samplePrompts = listOf(
            "Translate 'Welcome! How can I help you today?' into Hindi, Marathi, Gujarati, and French.",
            "Translate 'Namaste, main aapki kya sahayata kar sakta hoon?' into English.",
            "Give me 10 essential travel phrases in Japanese with pronunciation."
        )
    ),
    CategoryItem(
        id = "prompts",
        label = "AI Prompts",
        icon = Icons.Default.AutoAwesome,
        samplePrompts = listOf(
            "Generate a high-detail image prompt for a futuristic glowing neon temple in the mountains.",
            "Write a cinematic video generation prompt for Veo 3.1 describing a flying drone over futuristic Tokyo.",
            "Create 3 imaginative prompts for sci-fi story writing."
        )
    ),
    CategoryItem(
        id = "travel",
        label = "Travel & Planning",
        icon = Icons.Default.Flight,
        samplePrompts = listOf(
            "Create a 3-day budget travel itinerary for exploring Kyoto, Japan.",
            "What are top 5 safety tips when traveling internationally solo?",
            "Plan a weekend road trip itinerary starting from Mumbai to Lonavala."
        )
    )
)

@Composable
fun PromptCategoryChips(
    activeCategory: String,
    onCategorySelected: (String) -> Unit,
    onPromptSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        // Category Chips Row
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(CATEGORIES) { cat ->
                val isSelected = activeCategory == cat.id
                val bg = if (isSelected) AiAccentCyan.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant
                val border = if (isSelected) AiAccentCyan else Color.Transparent

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(bg)
                        .border(1.dp, border, RoundedCornerShape(20.dp))
                        .clickable { onCategorySelected(if (isSelected) "all" else cat.id) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("chip_category_${cat.id}")
                ) {
                    Icon(
                        imageVector = cat.icon,
                        contentDescription = null,
                        tint = if (isSelected) AiAccentCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = cat.label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Sample Prompts list for active category
        val currentCategoryObj = CATEGORIES.find { it.id == activeCategory }
        if (currentCategoryObj != null) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(currentCategoryObj.samplePrompts) { promptText ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .border(
                                width = 1.dp,
                                color = AiAccentPurple.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onPromptSelected(promptText) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("btn_sample_prompt")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = AiAccentPurple,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (promptText.length > 45) promptText.take(45) + "..." else promptText,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
