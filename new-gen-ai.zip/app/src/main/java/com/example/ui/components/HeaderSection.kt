package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AiAccentCyan
import com.example.ui.theme.AiAccentPurple

@Composable
fun HeaderSection(
    selectedModel: String,
    onModelSelected: (String) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenInfo: () -> Unit,
    onNewChat: () -> Unit,
    onOpenStarred: () -> Unit,
    starredCount: Int,
    userName: String? = null,
    userEmail: String? = null,
    onSignOut: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showModelMenu by remember { mutableStateOf(false) }
    var showUserMenu by remember { mutableStateOf(false) }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Logo & Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onOpenInfo() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(AiAccentCyan, AiAccentPurple)
                                )
                            )
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_launcher_foreground),
                            contentDescription = "NEW GEN AI Logo",
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "NEW GEN AI",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(AiAccentCyan.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "v3.5",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AiAccentCyan
                                )
                            }
                        }
                        Text(
                            text = "Created by Amit Dantani",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
                        )
                    }
                }

                // Right Actions: New Chat, History, Starred, Info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onNewChat,
                        modifier = Modifier.testTag("btn_new_chat")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "New Chat",
                            tint = AiAccentCyan
                        )
                    }

                    IconButton(
                        onClick = onOpenHistory,
                        modifier = Modifier.testTag("btn_chat_history")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Box {
                        IconButton(
                            onClick = onOpenStarred,
                            modifier = Modifier.testTag("btn_starred_messages")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Starred Messages",
                                tint = if (starredCount > 0) Color(0xFFFFB703) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onOpenInfo,
                        modifier = Modifier.testTag("btn_about_info")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "About Creator",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (userName != null || onSignOut != null) {
                        Box {
                            IconButton(
                                onClick = { showUserMenu = true },
                                modifier = Modifier.testTag("btn_user_profile")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(AiAccentCyan.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "User Account",
                                        tint = AiAccentCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = showUserMenu,
                                onDismissRequest = { showUserMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(userName ?: "Logged In User", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            if (userEmail != null) {
                                                Text(userEmail, fontSize = 11.sp, color = Color.Gray)
                                            }
                                        }
                                    },
                                    onClick = { }
                                )
                                if (onSignOut != null) {
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.ExitToApp,
                                                    contentDescription = "Sign Out",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Sign Out", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                            }
                                        },
                                        onClick = {
                                            showUserMenu = false
                                            onSignOut()
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sub-row: Active Engine Model Selector Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(
                                width = 1.dp,
                                color = AiAccentCyan.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable { showModelMenu = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("btn_model_selector")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = AiAccentCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (selectedModel.contains("pro")) "Gemini 3.1 Pro (Reasoning)" else "Gemini 3.5 Flash (Fast AI)",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    DropdownMenu(
                        expanded = showModelMenu,
                        onDismissRequest = { showModelMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text("Gemini 3.5 Flash", fontWeight = FontWeight.Bold)
                                    Text("Super-fast everyday responses, homework, multi-lingual", fontSize = 11.sp, color = Color.Gray)
                                }
                            },
                            onClick = {
                                onModelSelected("gemini-3.5-flash")
                                showModelMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text("Gemini 3.1 Pro Preview", fontWeight = FontWeight.Bold)
                                    Text("Advanced math, complex reasoning & deep coding", fontSize = 11.sp, color = Color.Gray)
                                }
                            },
                            onClick = {
                                onModelSelected("gemini-3.1-pro-preview")
                                showModelMenu = false
                            }
                        )
                    }
                }

                Text(
                    text = "Multilingual • Creative • Math & Code",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }
    }
}
