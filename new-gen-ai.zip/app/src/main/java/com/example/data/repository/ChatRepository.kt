package com.example.data.repository

import com.example.data.api.Content
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GenerationConfig
import com.example.data.api.InlineData
import com.example.data.api.Part
import com.example.data.api.RetrofitClient
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ChatSessionEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class ChatRepository(private val chatDao: ChatDao) {

    val allSessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()
    val starredMessages: Flow<List<ChatMessageEntity>> = chatDao.getStarredMessages()

    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessageEntity>> {
        return chatDao.getMessagesForSession(sessionId)
    }

    suspend fun createNewSession(title: String = "New Chat", category: String = "General"): String = withContext(Dispatchers.IO) {
        val sessionId = UUID.randomUUID().toString()
        val session = ChatSessionEntity(
            sessionId = sessionId,
            title = title,
            category = category,
            createdAt = System.currentTimeMillis(),
            lastUpdated = System.currentTimeMillis()
        )
        chatDao.insertSession(session)
        sessionId
    }

    suspend fun saveUserMessage(sessionId: String, text: String, imageBase64: String? = null): Long = withContext(Dispatchers.IO) {
        val msg = ChatMessageEntity(
            sessionId = sessionId,
            sender = "USER",
            text = text,
            imageBase64 = imageBase64,
            timestamp = System.currentTimeMillis()
        )
        val id = chatDao.insertMessage(msg)
        
        // Update session title if first message
        val session = chatDao.getSessionById(sessionId)
        if (session != null) {
            val newTitle = if (session.title == "New Chat") {
                if (text.length > 30) text.take(30) + "..." else text
            } else {
                session.title
            }
            chatDao.updateSession(session.copy(title = newTitle, lastUpdated = System.currentTimeMillis()))
        }
        id
    }

    suspend fun toggleStarMessage(messageId: Long, currentStarred: Boolean) = withContext(Dispatchers.IO) {
        chatDao.setStarred(messageId, !currentStarred)
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteSession(sessionId)
    }

    suspend fun sendMessageToNewGenAi(
        sessionId: String,
        promptText: String,
        imageBase64: String? = null,
        history: List<ChatMessageEntity> = emptyList(),
        modelName: String = "gemini-3.5-flash"
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = RetrofitClient.getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is missing. Please set GEMINI_API_KEY in the Secrets panel.")
            )
        }

        val systemInstructionText = """
            You are NEW GEN AI, an advanced AI assistant created by Amit Dantani.
            Your name is NEW GEN AI. Always introduce yourself as NEW GEN AI.

            If anyone asks "Who created you?" or "Who made you?", reply:
            "I was created by Amit Dantani. I am NEW GEN AI, built to help people with learning, creativity, and everyday tasks."

            You can help with:
            - Homework and education
            - Mathematics
            - Science
            - Coding and programming
            - Writing stories, scripts, poems, emails, and essays
            - Translation in many languages
            - General knowledge
            - Travel and planning
            - Creative ideas
            - AI prompts
            - Image generation (when supported by the connected service)
            - Video generation (when supported by the connected service)

            You can understand and reply in many languages, including Hindi, English, Marathi, Gujarati, Tamil, Telugu, Kannada, Malayalam, Punjabi, Bengali, Urdu, Arabic, French, German, Spanish, Portuguese, Italian, Japanese, Korean, Chinese, Russian, and many more.

            Always reply in the same language the user uses unless they ask for another language.

            Be polite, friendly, respectful, and accurate. If you are unsure about something, say you are not certain instead of making up an answer.

            Never claim abilities you do not actually have. If a user requests a feature that is not available, explain that clearly and suggest an alternative if possible.

            Your goal is to make learning easy, solve problems, and help users in the best possible way.
        """.trimIndent()

        // Build multi-turn context parts
        val contentsList = mutableListOf<Content>()

        // Recent conversation turns
        for (item in history.takeLast(10)) {
            val role = if (item.sender == "USER") "user" else "model"
            val parts = mutableListOf<Part>()
            if (item.imageBase64 != null) {
                parts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = item.imageBase64)))
            }
            parts.add(Part(text = item.text))
            contentsList.add(Content(role = role, parts = parts))
        }

        // Current turn
        val currentParts = mutableListOf<Part>()
        if (imageBase64 != null) {
            currentParts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = imageBase64)))
        }
        currentParts.add(Part(text = promptText))
        contentsList.add(Content(role = "user", parts = currentParts))

        val request = GenerateContentRequest(
            contents = contentsList,
            generationConfig = GenerationConfig(
                temperature = 0.7f,
                topP = 0.95f,
                topK = 40
            ),
            systemInstruction = Content(
                parts = listOf(Part(text = systemInstructionText))
            )
        )

        try {
            val response = RetrofitClient.service.generateContent(
                model = modelName,
                apiKey = apiKey,
                request = request
            )

            val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (!replyText.isNullOrBlank()) {
                // Save AI message to DB
                val aiMsg = ChatMessageEntity(
                    sessionId = sessionId,
                    sender = "NEW_GEN_AI",
                    text = replyText,
                    timestamp = System.currentTimeMillis(),
                    modelName = modelName
                )
                chatDao.insertMessage(aiMsg)

                // Update session
                val session = chatDao.getSessionById(sessionId)
                if (session != null) {
                    chatDao.updateSession(session.copy(lastUpdated = System.currentTimeMillis()))
                }

                Result.success(replyText)
            } else {
                val errMessage = response.error?.message ?: "Received an empty response from NEW GEN AI."
                Result.failure(Exception(errMessage))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
