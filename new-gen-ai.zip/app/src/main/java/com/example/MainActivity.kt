package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainChatScreen
import com.example.ui.theme.NewGenAiTheme
import com.example.ui.viewmodel.ChatViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NewGenAiTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val chatViewModel: ChatViewModel = viewModel()
                    val uiState by chatViewModel.uiState.collectAsState()

                    if (!uiState.isLoggedIn) {
                        LoginScreen(
                            onSignInSuccess = { email, name ->
                                chatViewModel.login(email, name)
                            }
                        )
                    } else {
                        MainChatScreen(viewModel = chatViewModel)
                    }
                }
            }
        }
    }
}
